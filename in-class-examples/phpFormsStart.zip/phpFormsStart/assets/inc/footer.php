</div> 
	<footer>Dan's Pizza Shoppe &reg;</footer>
</body>
</html>